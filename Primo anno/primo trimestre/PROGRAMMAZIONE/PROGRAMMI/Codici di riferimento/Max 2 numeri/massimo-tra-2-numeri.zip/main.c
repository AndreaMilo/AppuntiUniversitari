/******************************************************************************
    NOME: ANDREA MILO
*******************************************************************************/
#include <stdio.h>

int main()
{
    //Inizializzo variabili
    int num1=0, num2=0;
    
    //Inserire in input i valori
    printf("Inerisci i valori per trovare il massimo tra di loro \n");
    scanf("%d", &num1);
    scanf("%d", &num2);
    
    //Eseguire il controllo
    if(num1>num2){
        printf("Il numero piu' grande e': %d ", num1);
    }
    else if(num1==num2){
                printf("Sono uguali");
    }
    else printf("Il numero piu' grande e': %d ", num2);


    return 0;
}