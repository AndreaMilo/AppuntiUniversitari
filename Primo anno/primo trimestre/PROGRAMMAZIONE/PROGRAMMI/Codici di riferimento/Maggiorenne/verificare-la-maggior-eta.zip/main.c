/******************************************************************************

    NOME: ANDREA MILO
    Verificare se un utente è maggiorenne o meno

*******************************************************************************/
#include <stdio.h>
#define MAGGIORENNE 18 //Creazione della costante 18enne
int main()
{
    //Dichiarazioni variabili
    short eta=0;
    printf("Inserisci la tua eta' attuale \n");
    
    //Inizializzare dati in input
    scanf("%hd", &eta);
    
    //Controllo della maggior età
    if(eta<0){
        printf("Non hai inserito un eta' corretta\n ");
    }
    else {
        if(eta>=MAGGIORENNE) printf("L'utente e' maggiorenne");
        else printf("L'utente e' minorenne");
    }

    return 0;
}
