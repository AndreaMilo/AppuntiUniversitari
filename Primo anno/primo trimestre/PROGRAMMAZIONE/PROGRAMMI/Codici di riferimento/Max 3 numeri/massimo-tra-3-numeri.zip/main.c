/******************************************************************************

    NOME: ANDREA MILO

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Dichiarazione variabili
    int num1=0, num2=0, num3=0, max=0;
    printf("Inserire 3 valori per scoprire quale sia il piu' grande tra loro \n");
    
    //Inizializzazione delle variabili
    scanf("%d %d %d", &num1, &num2, &num3);
    
    //Controllo del massimo
    if(num1==num2 && num2==num3 && num3==num1){
        printf("Sono uguali");
    }
    else{
        if(num1>=num2 && num1>num3){
            max=num1;
            if(max>num3){
                printf("Il massimo e': %d ", max);
            }
            else printf("Il massimo e': %d ", num3);
        }
        else if(num2>=num1 && num2>=num3){
            max=num2;
            printf("Il masimo e': %d ", max);
        }
        else if(num3>=num1 && num3>=num2){
            max=num3;
            printf("Il masimo e': %d ", max);
        }
    }
    return 0;
}
